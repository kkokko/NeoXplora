<? 
include('config.php'); 
if (isset($_POST['submitted'])) { 
foreach($_POST AS $key => $value) { $_POST[$key] = mysql_real_escape_string($value); } 
$sql = "INSERT INTO `storyline` ( `storylineid` ,  `text` ,  `storyid`  ) VALUES(  '{$_POST['storylineid']}' ,  '{$_POST['text']}' ,  '{$_POST['storyid']}'  ) "; 
mysql_query($sql) or die(mysql_error()); 
echo "Added row.<br />"; 
echo "<a href='list.php'>Back To Listing</a>"; 
} 
?>

<form action='' method='POST'> 
<p><b>Storylineid:</b><br /><input type='text' name='storylineid'/> 
<p><b>Text:</b><br /><textarea name='text'></textarea> 
<p><b>Storyid:</b><br /><input type='text' name='storyid'/> 
<p><input type='submit' value='Add Row' /><input type='hidden' value='1' name='submitted' /> 
</form> 
