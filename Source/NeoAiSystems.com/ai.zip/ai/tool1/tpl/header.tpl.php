<?php 
error_reporting(E_ALL);
include 'include/common.php';
$answer = new Answer();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- Reset Stylesheet -->
		<link rel="stylesheet" href="css/reset.css" type="text/css" media="screen" />
	  
		<!-- Main Stylesheet -->
		<link rel="stylesheet" href="css/style.css" type="text/css" media="screen" />
		
		<script type="text/javascript" src="js/jquery.idTabs.min.js"></script>
		<link rel="stylesheet" href="css/styletabs.css" type="text/css" media="screen" />
<title>AI Tool1</title>
<style>

</style>
</head>

<body>
<div id="content">
	<div id="header" style="height: 40px; padding-top: 20px;padding-bottom: 20px;">
		<h1 style="font-size: 20px; font-weight: bold">AI Tool1 <span style="float:right;"><a href="admin.php?page=admin&tpl=dash">Admin</a></span></h1>
	</div>