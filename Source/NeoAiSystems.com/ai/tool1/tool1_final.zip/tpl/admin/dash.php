

<ul>
	<li>
		<a href="admin.php?page=category&tpl=list">Manage Categories </a>
	</li>
	<li>
		<a href="admin.php?page=story&tpl=list">Manage Stories</a>
	</li>
</ul>