
<?php 
include 'tpl/header.tpl.php';

//if form was saved
if(isset($_POST['submitted']))
{
	//foreach ()
	$post = $_POST;
	$updateStory = new Story();
	$updateStoryId = 0;
	//print_r(array_keys($_POST));
	$storyLineIds = array();
	$updatedStoryLines = array();
	$representationIds = array();
	$questionIds = array();
	$answerIds = array();
	$ruleIds = '';
	foreach ($post as $key=>$val)
	{
		if(!(strpos($key, 'storyLineId_') === false))
		{	
			$mykey = substr($key, strpos($key, '_')+1);			
			$storyLineIds[$mykey] = $val;
			$curObj = new StoryLine();			
			$curObj = $curObj->Get($mykey);
			$updateStoryId = $curObj->storyId;
			$curObj->text = $val;
			$curObj->Save();
			$updatedStoryLines[] = $val;
		}
		else if(!(strpos($key, 'representationId_') === false))
		{	
			$mykey = substr($key, strpos($key, '_')+1);			
			$representationIds[$mykey] = $val;
			$curObj = new Representation();
			$curObj = $curObj->Get($mykey);
			$curObj->text = $val;
			$curObj->Save();			 
		}
		else if(!(strpos($key, 'questionId_') === false))
		{	
			$mykey = substr($key, strpos($key, '_')+1);			
			$questionIds[$mykey] = $val;	
			$curObj = new Question();
			$curObj = $curObj->Get($mykey);
			$curObj->statement = $val;
			$curObj->Save();		 
		}
		else if(!(strpos($key, 'answerId_') === false))
		{	
			$mykey = substr($key, strpos($key, '_')+1);			
			$answerIds[$mykey] = $val;
			$curObj = new Answer();
			$curObj = $curObj->Get($mykey);
			$curObj->statement = $val;
			$curObj->Save();			 
		}
		else if(!(strpos($key, 'storyruleId_') === false))
		{	
			$mykey = substr($key, strpos($key, '_')+1);			
			$ruleIds[$mykey] = $val;
			$curObj = new StoryRule();
			$curObj = $curObj->Get($mykey);
			$curObj->statement = $val;
			$curObj->Save();			 
		}
		$updateStory = $updateStory->Get($updateStoryId);
		$storyBody = implode('.', $updatedStoryLines);
		$updateStory->body = $storyBody;
		$updateStory->Save();
		
	}
}

$categoryList = new Category();
$storyConditions = null;
$selected_cat = 0;
if(isset($_POST['changeCat']))
{	
	if(isset($_POST['categoryId']))
	{
		$selected_cat = $_POST['categoryId'];			
    	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=index.php?cid='.$selected_cat.'">';    
    	exit;
	}	
}
if(isset($_REQUEST['cid']))
{
	$selected_cat = $_REQUEST['cid'];
}
$categoryList = $categoryList->GetList();
$stories = new Story();

$allStoryConditions = null;
$conditions = null;
if($selected_cat !=0 )
{
	$allStoryConditions = array(array('categoryId', '=', $selected_cat));
}
if(isset($_REQUEST['sid']))
{
	$conditions = array(array('storyId', '=', $_REQUEST['sid']));
}
else 
{
	$conditions = $allStoryConditions;
}
$allstories = $stories->GetList($allStoryConditions);
$stories = $stories->GetList($conditions);
if(count($stories) > 0)
{
	$currStory = $stories[0];
}

//questions and answers for curr story

$questions = new Question();
if(isset($currStory))
{
	$questions = $questions->GetList(array(array('storyId', '=', $currStory->storyId)));
}
$answers = new Answer();

?>

	<form id="form1" name="form1" method="post" action="">
	  <label>categories
	  <select name="categoryId" id="categories" onchange="javascript:document.forms['form1'].submit();">
	    <option value="0">All</option>
	    <?php
	    foreach($categoryList as $aCat)
	    {
	    	$selected = "";
	    	if($selected_cat !=0  && $aCat->categoryId==$selected_cat)
	    	{
	    		$selected = 'selected="'.$selected_cat.'"' ;
	    	}
	    	?>
	    		<option value="<?=$aCat->categoryId ?>" <?=$selected ?>><?=$aCat->name ?></option>
	    	<?php 
	    } 
	    ?>
	  </select>
	  </label>
	  <input type="hidden" name="changeCat" value="1"/>
	</form>
<p>&nbsp;</p>
<p>&nbsp;</p>
<form name="form2" method="post" action="">
<table width="1200" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <th width="100" scope="col">Matching Stories</th>
    <th scope="col">Body</th>
    <th scope="col">Representation</th>
    <th scope="col">Questions</th>
    <th scope="col">Answers</th>
    <th scope="col">Rules</th>
  </tr>
  
  <tr>
  	<td>
  		<table>
  			<?php
  			if(count($stories)>0)
  			{
	  			foreach ($allstories as $astory)
	  			{ 
	  			?>
	  			<tr>
	  				<td>
	  					<a href="index.php?sid=<?=$astory->storyId ?>&cid=<?=$selected_cat ?>"><?=$astory->title ?></a>
	  				</td>
	  			</tr>
	  			<?php 
	  			}
  			}
  			else 
  			{
  				?>
  				<tr><td>None found</td></tr>
  				<?php 
  			}
  			?>
  		</table>
  	</td>
  	<?php 
  	if(count($stories)>0)
  	{
  	?>
  			
  	<td width="260">
  		<?
  			$storylines = new StoryLine();
  			$representations = array();
  			if(isset($currStory))
  			{
  				$storylines = $storylines->GetList(array(array('storyId', '=', $currStory->storyId)));
  			
	  		 	//$currStory->body
	  		 	$linenumber = 1;
	  		 	foreach ($storylines as $line)
	  		 	{
	  		 		  		 		
	  		 		if($line->text != '')
	  		 		{
	  		 			//set the representation of this line
	  		 			$representation = new Representation();
		  		 		$representation = $representation->GetList(array(array('storylineId', '=', $line->storylineId)));
		  		 		$representation = $representation[0];
		  		 		$representations[] = $representation;
		  		 		//display story lines inputs
		  		 		echo '<label>'.str_pad($linenumber, 2, "0", STR_PAD_LEFT). '. ';
		  		 		echo '<input name="storyLineId_'.$line->storylineId.'" type="text" value="'.$line->text.'"/>';  	
		  		 		//echo $line->text;
		  		 		echo '</label><br />';
		  		 		$linenumber++;
	  		 		}
	  		 	}
  			}
  		 ?>
  	</td>
  	<td>
  		<?  			
  			foreach ($representations as $aRep)
  		 	{  		 		
  		 		echo '<input name="representationId_'.$aRep->representationId.'" type="text" value="'.$aRep->text.'"/>';
  		 	}
  		?>
  	</td>
  	<td>
  		
  		<?php 
  		foreach ($questions as $quest)
  		{
  			echo '<textarea name="questionId_'.$quest->questionId.'" rows="" cols="">'.$quest->statement .'</textarea><br />';
  			//echo '<br />'; 
  		}
  		?>
  		
  	</td>
  	<td>
  	<?php 
  		foreach ($questions as $quest)
  		{
  			$answer = new Answer();
  			$answer = $answer->GetList(array(array('questionId', '=', $quest->questionId)));
  			$answer = $answer[0];
  			//echo $answer->statement;
  			echo '<textarea name="answerId_'.$answer->answerId.'" rows="" cols="">'.$answer->statement .'</textarea>';
  			echo '<br />'; 
  		}
  	?>
  	</td>
  	<td>
  		<?php 
  			$storyRules = new StoryRule();
  			$storyRules = $storyRules->GetList(array(array('storyId', '=', $currStory->storyId)));
  			if(count($storyRules)>0)
  			{
  				//$storyRules = $storyRules[0];
  				foreach ($storyRules as $aRule)
  				{
  			  				  			
  		?>
  		<textarea name="storyruleId_<?=$aRule->storyruleId ?>" rows="" cols=""><?= $aRule->statement ?></textarea>
  		<?php 
  				}
  			}
  		?>
  	</td>  	
  </tr>
  <tr>
  	<td colspan="6">
  		<input type="hidden" name="submitted" value="1" /> 
  		<input style="width: 75px;" type="submit" value="Save" />
  	</td>
  	<?php 
  	}
  	?>
  </tr>
</table>
</form>
<p>&nbsp;</p>
	
	<a href="admin.php?page=admin&tpl=dash">Admin</a>
<?php 
include 'tpl/footer.tpl.php';
?>



	
